// Alternate way for exporting all the action creators through single file.
export * as actionCreators from './action-creators/index'