let movies = [
  "Suraj par mangal bhari",
  "Tenet",
  "The war with grandpa",
  "The personal history of David Copperfield",
  "Come Play",
];
let slots = ["10:00 AM", "01:00 PM", "03:00 PM", "08:00 PM"];
let seats = ["A1", "A2", "A3", "A4", "D1", "D2"];
exports.movies = movies;
exports.slots = slots;
exports.seats = seats;
